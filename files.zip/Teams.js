import React from "react";

export function Teams(props) {
  const {
    data,
    team,
    edit,
    editId,
    empId,
    empName,
    experience,
    handleDelete,
    handleEdit,
    handleChange,
    handleCancel,
    handleDone,
  } = props;

  return (
    <>
      {team.map((t) => {
        const members = data.filter((m) => m.technology_name === t.name);
        if (members.length === 0) return null;
        return (
          <table key={t._id}>
            <thead>
              <tr>
                <td>{t.name}</td>
              </tr>
            </thead>
            <tbody>
              {members.map((member, index) => (
                <tr key={member._id}>
                  {edit && editId === member._id ? (
                    <>
                      <td>{index + 1}</td>
                      <td>
                        <input
                          type="number"
                          name="empId"
                          value={empId}
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input
                          type="text"
                          name="empName"
                          value={empName}
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <input
                          type="number"
                          name="experience"
                          value={experience}
                          onChange={handleChange}
                        />
                      </td>
                      <td>
                        <button
                          onClick={handleDone}
                          disabled={
                            empId === "" ||
                            empName === "" ||
                            experience === ""
                          }
                        >
                          Done
                        </button>
                      </td>
                      <td>
                        <button onClick={handleCancel}>Cancel</button>
                      </td>
                    </>
                  ) : (
                    <>
                      <td>{index + 1}</td>
                      <td>{member.employee_id}</td>
                      <td>{member.employee_name}</td>
                      <td>{member.experience}</td>
                      <td>
                        <button onClick={() => handleEdit(member._id)}>
                          Edit
                        </button>
                      </td>
                      <td>
                        <button onClick={(e) => handleDelete(e, member._id)}>
                          Delete
                        </button>
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        );
      })}
    </>
  );
}

Teams.defaultProps = {
  data: [],
  team: [],
  edit: false,
  editId: undefined,
  empId: "",
  empName: "",
  experience: "",
  handleDelete: () => {},
  handleEdit: () => {},
  handleChange: () => {},
  handleCancel: () => {},
  handleDone: () => {},
};

export default Teams;
