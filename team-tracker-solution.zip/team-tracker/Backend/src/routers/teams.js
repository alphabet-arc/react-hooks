const express = require("express");
const membersRouter = new express.Router();
const Members = require("../mongoose/models/members");
const Teams = require("../mongoose/models/teams");
const Admin = require("../mongoose/models/admin");
const auth = require("../middlewares/auth");
const jwt = require("jsonwebtoken");
const { secret_token } = require("../../helper");

// 1) POST /admin/login
membersRouter.post("/admin/login", async (req, res) => {
  try {
    const { name, password } = req.body;
    const admin = await Admin.findOne({ name, password });
    if (!admin) {
      return res.status(400).json({ error: "Username or password is wrong" });
    }
    const token = jwt.sign({ _id: admin._id.toString() }, secret_token);
    admin.tokens = admin.tokens.concat({ token });
    await admin.save();
    res.status(200).json({ admin, token });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// 2) POST /tracker/members/add
membersRouter.post("/tracker/members/add", auth, async (req, res) => {
  try {
    const { employee_id, employee_name, technology_name, experience } = req.body;

    // Check if team exists, if not add it
    let team = await Teams.findOne({ name: technology_name });
    if (!team) {
      team = new Teams({ name: technology_name });
      await team.save();
    }

    // Check if member with same employee_id and technology_name exists
    const existing = await Members.findOne({ employee_id, technology_name });
    if (existing) {
      return res.status(400).json({ error: "Member with same team already exists" });
    }

    const member = new Members({ employee_id, employee_name, technology_name, experience });
    await member.save();
    res.status(201).json(member);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// 3) GET /tracker/technologies/get
membersRouter.get("/tracker/technologies/get", auth, async (req, res) => {
  try {
    const teams = await Teams.find({});
    res.status(200).json(teams);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// 4) POST /tracker/technologies/add
membersRouter.post("/tracker/technologies/add", auth, async (req, res) => {
  try {
    const { name } = req.body;
    const existing = await Teams.findOne({ name });
    if (existing) {
      return res.status(400).json({ error: "Team already exist" });
    }
    const team = new Teams({ name });
    await team.save();
    res.status(201).json(team);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// 5) DELETE /tracker/technologies/add
membersRouter.delete("/tracker/technologies/add", auth, async (req, res) => {
  try {
    const { name } = req.body;
    const team = await Teams.findOneAndDelete({ name });
    if (!team) {
      return res.status(400).json({ error: "Couldn't delete the team" });
    }
    res.status(200).json(team);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// 6) PATCH /tracker/members/update/:id
membersRouter.patch("/tracker/members/update/:id", auth, async (req, res) => {
  try {
    const member = await Members.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!member) {
      return res.status(400).json({ error: "Member not found" });
    }
    res.status(200).json(member);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// 7) GET /tracker/members/display
membersRouter.get("/tracker/members/display", auth, async (req, res) => {
  try {
    const { tech, experience } = req.query;
    let filter = {};
    if (tech) filter.technology_name = tech;
    if (experience) filter.experience = { $gte: Number(experience) };
    const members = await Members.find(filter);
    res.status(200).json(members);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// 8) DELETE /tracker/members/delete/:id
membersRouter.delete("/tracker/members/delete/:id", auth, async (req, res) => {
  try {
    const member = await Members.findByIdAndDelete(req.params.id);
    if (!member) {
      return res.status(400).json({ error: "Member not found" });
    }
    res.status(200).json(member);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// Move member - update technology_name
membersRouter.patch("/tracker/members/move", auth, async (req, res) => {
  try {
    const { employee_id, from, to } = req.body;
    const member = await Members.findOneAndUpdate(
      { employee_id, technology_name: from },
      { technology_name: to },
      { new: true, runValidators: true }
    );
    if (!member) {
      return res.status(400).json({ error: "Member not found" });
    }
    res.status(200).json(member);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

module.exports = membersRouter;
