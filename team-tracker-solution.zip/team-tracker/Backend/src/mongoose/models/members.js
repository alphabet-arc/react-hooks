const mongoose = require("mongoose");

const membersSchema = new mongoose.Schema({
  employee_id: {
    type: Number,
    required: true,
    min: 100000,
    max: 3000000,
  },
  employee_name: {
    type: String,
    required: true,
    validate: {
      validator: function (v) {
        return /^[a-zA-Z ]+$/.test(v) && v.length > 2;
      },
      message: "Employee name can have only alphabets and spaces and should have at least 3 letters",
    },
  },
  technology_name: {
    type: String,
    required: true,
  },
  experience: {
    type: Number,
    required: true,
    min: 0,
  },
});

const Members = mongoose.model("Members", membersSchema);

module.exports = Members;
