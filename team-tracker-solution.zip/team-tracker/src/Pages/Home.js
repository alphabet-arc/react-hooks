import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import Header from "../Components/Header";
import Teams from "../Components/Teams";

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      team: [],
      filterBy: "Both",
      selectedTeam: "",
      experience: "",
      editId: null,
      empId: "",
      empName: "",
      empExp: "",
      edit: false,
    };
  }

  getLocalStorage = () => {
    return localStorage.getItem("token");
  };

  componentDidMount() {
    const token = this.getLocalStorage();
    if (!token) {
      this.props.history.push("/login");
      return;
    }
    this.handleGetMembers();
    this.handleGetTech();
  }

  handleGetMembers = async (query = "") => {
    try {
      const token = this.getLocalStorage();
      const res = await fetch(`/api/tracker/members/display${query}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      this.setState({ data });
    } catch (e) {}
  };

  handleGetTech = async () => {
    try {
      const token = this.getLocalStorage();
      const res = await fetch("/api/tracker/technologies/get", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const team = await res.json();
      this.setState({ team });
    } catch (e) {}
  };

  handleGo = () => {
    const { filterBy, selectedTeam, experience } = this.state;
    let query = "?";
    if (filterBy === "Team") query += `tech=${selectedTeam}`;
    else if (filterBy === "Experience") query += `experience=${experience}`;
    else if (filterBy === "Both")
      query += `tech=${selectedTeam}&experience=${experience}`;
    this.handleGetMembers(query);
  };

  handleClear = () => {
    this.setState({
      selectedTeam: "",
      experience: "",
      filterBy: "Both",
    });
    this.handleGetMembers();
  };

  handleDeleteMembers = async (id) => {
    try {
      const token = this.getLocalStorage();
      await fetch(`/api/tracker/members/delete/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      this.handleGetMembers();
    } catch (e) {}
  };

  handleEdit = (id) => {
    this.setState({ edit: true, editId: id });
  };

  handleEditRequest = async (id) => {
    try {
      const token = this.getLocalStorage();
      const { empId, empName, empExp } = this.state;
      await fetch(`/api/tracker/members/update/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          employee_id: Number(empId),
          employee_name: empName,
          experience: Number(empExp),
        }),
      });
      this.setState({ edit: false, editId: null });
      this.handleGetMembers();
    } catch (e) {}
  };

  isGoValid = () => {
    const { filterBy, selectedTeam, experience } = this.state;
    if (filterBy === "Experience") return experience.trim() !== "";
    if (filterBy === "Team")
      return selectedTeam !== "" && selectedTeam !== "--Select Team--";
    if (filterBy === "Both")
      return (
        selectedTeam !== "" &&
        selectedTeam !== "--Select Team--" &&
        experience.trim() !== ""
      );
    return false;
  };

  render() {
    const {
      data,
      team,
      filterBy,
      selectedTeam,
      experience,
      editId,
      empId,
      empName,
      empExp,
      edit,
    } = this.state;

    return (
      <div>
        <Header />
        <section style={styles.container}>
          <section style={styles.filterRow}>
            <label>Filter By </label>
            <section>
              <input
                type="radio"
                value="Experience"
                checked={filterBy === "Experience"}
                onChange={() => this.setState({ filterBy: "Experience" })}
              />
              <label> Experience</label>
            </section>
            <section>
              <input
                type="radio"
                value="Team"
                checked={filterBy === "Team"}
                onChange={() => this.setState({ filterBy: "Team" })}
              />
              <label> Team</label>
            </section>
            <section>
              <input
                type="radio"
                value="Both"
                checked={filterBy === "Both"}
                onChange={() => this.setState({ filterBy: "Both" })}
              />
              <label> Both</label>
            </section>
            <select
              value={selectedTeam}
              onChange={(e) => this.setState({ selectedTeam: e.target.value })}
              style={styles.select}
            >
              <option value="">--Select Team--</option>
              {team.map((t) => (
                <option key={t._id} value={t.name}>
                  {t.name}
                </option>
              ))}
            </select>
            <input
              type="number"
              placeholder="Experience"
              value={experience}
              onChange={(e) => this.setState({ experience: e.target.value })}
              style={styles.expInput}
            />
            <button
              onClick={this.handleGo}
              disabled={!this.isGoValid()}
              style={{
                ...styles.btn,
                backgroundColor: this.isGoValid() ? "#2c3e50" : "#95a5a6",
                cursor: this.isGoValid() ? "pointer" : "not-allowed",
              }}
            >
              Go
            </button>
            <button
              onClick={this.handleClear}
              style={{ ...styles.btn, backgroundColor: "#2c3e50" }}
            >
              Clear
            </button>
          </section>
          <Teams
            data={data}
            onDelete={this.handleDeleteMembers}
            onEdit={this.handleEdit}
            onEditRequest={this.handleEditRequest}
            editId={editId}
            edit={edit}
            empId={empId}
            empName={empName}
            empExp={empExp}
            onStateChange={(s) => this.setState(s)}
          />
        </section>
      </div>
    );
  }
}

const styles = {
  container: { padding: "20px" },
  filterRow: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    marginBottom: "20px",
    flexWrap: "wrap",
  },
  select: { padding: "5px", borderRadius: "4px" },
  expInput: {
    padding: "5px",
    borderRadius: "4px",
    border: "1px solid #ccc",
    width: "100px",
  },
  btn: {
    padding: "6px 14px",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
  },
};

export default withRouter(Home);
