import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import Header from "../Components/Header";

class MoveMember extends Component {
  constructor(props) {
    super(props);
    this.state = {
      employeeId: "",
      fromTeam: "",
      toTeam: "",
      teams: [],
    };
  }

  getLocalStorage = () => {
    return localStorage.getItem("token");
  };

  componentDidMount() {
    const token = this.getLocalStorage();
    if (!token) {
      this.props.history.push("/login");
      return;
    }
    this.handleGetTech();
  }

  handleGetTech = async () => {
    try {
      const token = this.getLocalStorage();
      const res = await fetch("/api/tracker/technologies/get", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const teams = await res.json();
      this.setState({ teams });
    } catch (e) {}
  };

  isFormValid = () => {
    const { employeeId, fromTeam, toTeam } = this.state;
    return (
      employeeId.trim() !== "" &&
      fromTeam !== "" &&
      fromTeam !== "--Select Team--" &&
      toTeam !== "" &&
      toTeam !== "--Select Team--"
    );
  };

  handleMoveMember = async () => {
    const { employeeId, fromTeam, toTeam } = this.state;
    try {
      const token = this.getLocalStorage();
      const res = await fetch("/api/tracker/members/move", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          employee_id: Number(employeeId),
          from: fromTeam,
          to: toTeam,
        }),
      });
      if (res.ok) {
        this.handleClear();
      } else {
        const data = await res.json();
        alert(data.error || "Error moving member");
      }
    } catch (e) {}
  };

  handleClear = () => {
    this.setState({ employeeId: "", fromTeam: "", toTeam: "" });
  };

  render() {
    const { employeeId, fromTeam, toTeam, teams } = this.state;

    return (
      <div>
        <Header />
        <div style={styles.container}>
          <form style={styles.card}>
            <h3>Move Team Member</h3>
            <input
              type="number"
              placeholder="Employee ID"
              value={employeeId}
              onChange={(e) => this.setState({ employeeId: e.target.value })}
              style={styles.input}
              className="MoveMember input"
            />
            <div style={styles.row}>
              <span>From: </span>
              <select
                value={fromTeam}
                onChange={(e) => this.setState({ fromTeam: e.target.value })}
                style={styles.select}
              >
                <option value="">--Select Team--</option>
                {teams.map((t) => (
                  <option key={t._id} value={t.name}>
                    {t.name}
                  </option>
                ))}
              </select>
              <span>To: </span>
              <select
                value={toTeam}
                onChange={(e) => this.setState({ toTeam: e.target.value })}
                style={styles.select}
              >
                <option value="">--Select Team--</option>
                {teams.map((t) => (
                  <option key={t._id} value={t.name}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
            <div style={styles.btnRow}>
              <button
                type="button"
                onClick={this.handleMoveMember}
                disabled={!this.isFormValid()}
                style={{
                  ...styles.outlineBtn,
                  borderColor: this.isFormValid() ? "#333" : "#ccc",
                  color: this.isFormValid() ? "#333" : "#ccc",
                  cursor: this.isFormValid() ? "pointer" : "not-allowed",
                }}
              >
                Move
              </button>
              <button
                type="button"
                onClick={this.handleClear}
                style={{
                  ...styles.outlineBtn,
                  borderColor: "#e74c3c",
                  color: "#e74c3c",
                }}
              >
                Clear
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

const styles = {
  container: { padding: "20px", display: "flex", justifyContent: "center" },
  card: {
    border: "1px solid #ccc",
    borderRadius: "8px",
    padding: "30px",
    width: "420px",
    display: "flex",
    flexDirection: "column",
    gap: "15px",
  },
  input: {
    padding: "8px",
    border: "1px solid #ccc",
    borderRadius: "4px",
    width: "100%",
    boxSizing: "border-box",
  },
  select: { padding: "8px", borderRadius: "4px", flex: 1 },
  row: { display: "flex", alignItems: "center", gap: "8px" },
  btnRow: {
    display: "flex",
    gap: "10px",
    justifyContent: "center",
    marginTop: "10px",
  },
  outlineBtn: {
    padding: "8px 30px",
    backgroundColor: "transparent",
    border: "1px solid",
    borderRadius: "20px",
    cursor: "pointer",
    fontWeight: "bold",
  },
};

export default withRouter(MoveMember);
