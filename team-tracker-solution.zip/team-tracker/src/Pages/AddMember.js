import React, { Component } from "react";
import { withRouter } from "react-router-dom";
import Header from "../Components/Header";

class AddMember extends Component {
  constructor(props) {
    super(props);
    this.state = {
      employeeId: "",
      employeeName: "",
      selectedTeam: "",
      experience: "",
      teams: [],
      showAddTeam: false,
      newTeam: "",
      showDeleteTeam: false,
    };
  }

  getLocalStorage = () => {
    return localStorage.getItem("token");
  };

  componentDidMount() {
    const token = this.getLocalStorage();
    if (!token) {
      this.props.history.push("/login");
      return;
    }
    this.handleGetTech();
  }

  handleGetTech = async () => {
    try {
      const token = this.getLocalStorage();
      const res = await fetch("/api/tracker/technologies/get", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const teams = await res.json();
      this.setState({ teams });
    } catch (e) {}
  };

  getIdError = () => {
    const { employeeId } = this.state;
    if (employeeId === "") return "*Please enter a value";
    const id = Number(employeeId);
    if (id < 100000 || id > 3000000)
      return "*Employee ID is expected between 100000 and 3000000";
    return "";
  };

  getNameError = () => {
    const { employeeName } = this.state;
    if (employeeName === "") return "*Please enter a value";
    if (!/^[a-zA-Z ]+$/.test(employeeName))
      return "Employee name can have only alphabets and spaces";
    if (employeeName.trim().length < 3)
      return "Employee Name should have at least 3 letters";
    return "";
  };

  getExpError = () => {
    const { experience } = this.state;
    if (experience === "") return "*Please enter a value";
    return "";
  };

  isFormValid = () => {
    const { selectedTeam } = this.state;
    return (
      this.getIdError() === "" &&
      this.getNameError() === "" &&
      this.getExpError() === "" &&
      selectedTeam !== "" &&
      selectedTeam !== "--Select Team--"
    );
  };

  handleAction = async () => {
    const { employeeId, employeeName, selectedTeam, experience } = this.state;
    try {
      const token = this.getLocalStorage();
      const res = await fetch("/api/tracker/members/add", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          employee_id: Number(employeeId),
          employee_name: employeeName,
          technology_name: selectedTeam,
          experience: Number(experience),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert(
          data.error ||
            "Member already exist in the team which you are adding"
        );
      } else {
        this.handleReset();
      }
    } catch (e) {}
  };

  handleReset = () => {
    this.setState({
      employeeId: "",
      employeeName: "",
      selectedTeam: "",
      experience: "",
    });
  };

  handleAddOrDeleteTeam = async (action, name) => {
    const token = this.getLocalStorage();
    if (action === "add") {
      const { newTeam } = this.state;
      try {
        const res = await fetch("/api/tracker/technologies/add", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ name: newTeam }),
        });
        if (!res.ok) {
          alert("Team already exist");
        } else {
          this.setState({ newTeam: "", showAddTeam: false });
          this.handleGetTech();
        }
      } catch (e) {}
    } else if (action === "delete") {
      try {
        const res = await fetch("/api/tracker/technologies/add", {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ name }),
        });
        if (!res.ok) {
          alert("Couldn't delete the team");
        } else {
          this.handleGetTech();
        }
      } catch (e) {}
    }
  };

  render() {
    const {
      employeeId,
      employeeName,
      selectedTeam,
      experience,
      teams,
      showAddTeam,
      newTeam,
      showDeleteTeam,
    } = this.state;

    return (
      <div>
        <Header />
        <div style={styles.container}>
          <form style={styles.card}>
            <h3>Add Team Member</h3>
            <input
              type="number"
              placeholder="Employee ID"
              value={employeeId}
              onChange={(e) => this.setState({ employeeId: e.target.value })}
              style={styles.input}
            />
            {employeeId !== "" && this.getIdError() && (
              <span style={styles.error}>{this.getIdError()}</span>
            )}
            <input
              type="text"
              placeholder="Employee Name"
              value={employeeName}
              onChange={(e) => this.setState({ employeeName: e.target.value })}
              style={styles.input}
            />
            {employeeName !== "" && this.getNameError() && (
              <span style={styles.error}>{this.getNameError()}</span>
            )}
            <div style={styles.teamRow}>
              <select
                value={selectedTeam}
                onChange={(e) =>
                  this.setState({ selectedTeam: e.target.value })
                }
                style={styles.select}
              >
                <option value="">--Select Team--</option>
                {teams.map((t) => (
                  <option key={t._id} value={t.name}>
                    {t.name}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() =>
                  this.setState((prev) => ({
                    showAddTeam: !prev.showAddTeam,
                    showDeleteTeam: false,
                  }))
                }
                style={styles.smallBtn}
              >
                +
              </button>
              <button
                type="button"
                onClick={() =>
                  this.setState((prev) => ({
                    showDeleteTeam: !prev.showDeleteTeam,
                    showAddTeam: false,
                  }))
                }
                style={{ ...styles.smallBtn, backgroundColor: "#e74c3c" }}
              >
                Delete
              </button>
            </div>

            {showAddTeam && (
              <div style={styles.addTeamRow}>
                <input
                  type="text"
                  placeholder="Team name"
                  value={newTeam}
                  onChange={(e) => this.setState({ newTeam: e.target.value })}
                  style={styles.input}
                />
                <button
                  type="button"
                  onClick={() => this.handleAddOrDeleteTeam("add")}
                  style={styles.smallBtn}
                >
                  save
                </button>
                <button
                  type="button"
                  onClick={() =>
                    this.setState({ showAddTeam: false, newTeam: "" })
                  }
                  style={{ ...styles.smallBtn, backgroundColor: "#95a5a6" }}
                >
                  cancel
                </button>
              </div>
            )}

            {showDeleteTeam && (
              <div style={styles.deleteTeamList}>
                {teams.map((t) => (
                  <div key={t._id} style={styles.deleteTeamItem}>
                    <span>{t.name}</span>
                    <button
                      type="button"
                      onClick={() =>
                        this.handleAddOrDeleteTeam("delete", t.name)
                      }
                      style={{
                        ...styles.smallBtn,
                        backgroundColor: "#e74c3c",
                      }}
                    >
                      x
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => this.setState({ showDeleteTeam: false })}
                  style={{ ...styles.smallBtn, backgroundColor: "#95a5a6" }}
                >
                  cancel
                </button>
              </div>
            )}

            <input
              type="number"
              placeholder="Experience"
              value={experience}
              onChange={(e) => this.setState({ experience: e.target.value })}
              style={styles.input}
            />
            {experience !== "" && this.getExpError() && (
              <span style={styles.error}>{this.getExpError()}</span>
            )}

            <div style={styles.btnRow}>
              <button
                type="button"
                onClick={this.handleAction}
                disabled={!this.isFormValid()}
                style={{
                  ...styles.outlineBtn,
                  borderColor: this.isFormValid() ? "#333" : "#ccc",
                  color: this.isFormValid() ? "#333" : "#ccc",
                  cursor: this.isFormValid() ? "pointer" : "not-allowed",
                }}
              >
                Add
              </button>
              <button
                type="button"
                onClick={this.handleReset}
                style={{
                  ...styles.outlineBtn,
                  borderColor: "#e74c3c",
                  color: "#e74c3c",
                }}
              >
                Clear
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

const styles = {
  container: { padding: "20px", display: "flex", justifyContent: "center" },
  card: {
    border: "1px solid #ccc",
    borderRadius: "8px",
    padding: "30px",
    width: "400px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  input: {
    padding: "8px",
    border: "1px solid #ccc",
    borderRadius: "4px",
    width: "100%",
    boxSizing: "border-box",
  },
  select: { padding: "8px", borderRadius: "4px", flex: 1 },
  teamRow: { display: "flex", gap: "8px", alignItems: "center" },
  addTeamRow: { display: "flex", gap: "8px", alignItems: "center" },
  smallBtn: {
    padding: "5px 10px",
    backgroundColor: "#2c3e50",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
  btnRow: {
    display: "flex",
    gap: "10px",
    justifyContent: "center",
    marginTop: "10px",
  },
  outlineBtn: {
    padding: "8px 30px",
    backgroundColor: "transparent",
    border: "1px solid",
    borderRadius: "20px",
    cursor: "pointer",
    fontWeight: "bold",
  },
  error: { color: "red", fontSize: "12px" },
  deleteTeamList: { display: "flex", flexDirection: "column", gap: "5px" },
  deleteTeamItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
};

export default withRouter(AddMember);
