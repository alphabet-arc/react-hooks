import React, { Component } from "react";

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      password: "",
    };
  }

  componentDidMount() {
    localStorage.clear();
  }

  handleLogin = async () => {
    const { name, password } = this.state;
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, password }),
      });
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("token", data.token);
        this.props.history.push("/");
      } else {
        alert("Invalid Credentials");
      }
    } catch (e) {
      alert("Invalid Credentials");
    }
  };

  render() {
    const { name, password } = this.state;
    const isValid = name.trim() !== "" && password.trim() !== "";

    return (
      <div style={styles.container}>
        <div style={styles.card}>
          <h2 style={styles.title}>Login</h2>
          <input
            type="text"
            placeholder="Username"
            value={name}
            onChange={(e) => this.setState({ name: e.target.value })}
            style={styles.input}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => this.setState({ password: e.target.value })}
            style={styles.input}
          />
          <button
            onClick={this.handleLogin}
            disabled={!isValid}
            style={{
              ...styles.button,
              backgroundColor: isValid ? "#e74c3c" : "#ccc",
              cursor: isValid ? "pointer" : "not-allowed",
            }}
          >
            Login
          </button>
        </div>
      </div>
    );
  }
}

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
    backgroundColor: "#f0f0f0",
  },
  card: {
    display: "flex",
    flexDirection: "column",
    padding: "40px",
    border: "1px solid #ccc",
    borderRadius: "8px",
    backgroundColor: "#fff",
    width: "300px",
  },
  title: {
    color: "#e74c3c",
    textAlign: "center",
    marginBottom: "20px",
  },
  input: {
    marginBottom: "15px",
    padding: "8px 0",
    borderTop: "none",
    borderLeft: "none",
    borderRight: "none",
    borderBottom: "1px solid #333",
    outline: "none",
    fontSize: "14px",
  },
  button: {
    padding: "10px",
    border: "none",
    borderRadius: "4px",
    color: "#fff",
    fontSize: "16px",
    marginTop: "10px",
  },
};

export default Login;
