import React, { Component } from "react";

class Teams extends Component {
  isEditValid = () => {
    const { empId, empName, empExp } = this.props;
    const idNum = Number(empId);
    const nameValid =
      /^[a-zA-Z ]+$/.test(empName) && empName.trim().length >= 3;
    const idValid = idNum >= 100000 && idNum <= 3000000;
    const expValid = empExp !== "" && !isNaN(Number(empExp));
    return nameValid && idValid && expValid;
  };

  render() {
    const {
      data,
      onDelete,
      onEdit,
      onEditRequest,
      editId,
      empId,
      empName,
      empExp,
      onStateChange,
    } = this.props;

    // Group members by technology_name
    const grouped = (data || []).reduce((acc, member) => {
      if (!acc[member.technology_name]) acc[member.technology_name] = [];
      acc[member.technology_name].push(member);
      return acc;
    }, {});

    return (
      <div>
        {Object.keys(grouped).map((team) => (
          <div key={team} style={styles.teamBlock}>
            <div style={styles.teamHeader}>{team}</div>
            <table style={styles.table}>
              <tbody>
                {grouped[team].map((member, idx) => (
                  <tr key={member._id}>
                    <td style={styles.td}>{idx + 1}</td>
                    {editId === member._id ? (
                      <>
                        <td style={styles.td}>
                          <input
                            type="number"
                            value={empId}
                            onChange={(e) =>
                              onStateChange({ empId: e.target.value })
                            }
                            style={styles.input}
                          />
                        </td>
                        <td style={styles.td}>
                          <input
                            type="text"
                            value={empName}
                            onChange={(e) =>
                              onStateChange({ empName: e.target.value })
                            }
                            style={styles.input}
                          />
                        </td>
                        <td style={styles.td}>
                          <input
                            type="number"
                            value={empExp}
                            onChange={(e) =>
                              onStateChange({ empExp: e.target.value })
                            }
                            style={styles.input}
                          />
                        </td>
                        <td style={styles.td}>
                          <button
                            onClick={() => onEditRequest(member._id)}
                            disabled={!this.isEditValid()}
                            style={{
                              ...styles.btn,
                              backgroundColor: this.isEditValid()
                                ? "#2c3e50"
                                : "#95a5a6",
                            }}
                          >
                            Done
                          </button>
                        </td>
                        <td style={styles.td}>
                          <button
                            onClick={() =>
                              onStateChange({ editId: null, edit: false })
                            }
                            style={{
                              ...styles.btn,
                              backgroundColor: "#95a5a6",
                            }}
                          >
                            Cancel
                          </button>
                        </td>
                      </>
                    ) : (
                      <>
                        <td style={styles.td}>{member.employee_id}</td>
                        <td style={styles.td}>{member.employee_name}</td>
                        <td style={styles.td}>{member.experience}</td>
                        <td style={styles.td}>
                          <button
                            onClick={() => {
                              onEdit(member._id);
                              onStateChange({
                                empId: member.employee_id,
                                empName: member.employee_name,
                                empExp: member.experience,
                              });
                            }}
                            style={{
                              ...styles.btn,
                              backgroundColor: "#2c3e50",
                            }}
                          >
                            Edit
                          </button>
                        </td>
                        <td style={styles.td}>
                          <button
                            onClick={() => onDelete(member._id)}
                            style={{
                              ...styles.btn,
                              backgroundColor: "#e74c3c",
                            }}
                          >
                            Delete
                          </button>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
      </div>
    );
  }
}

const styles = {
  teamBlock: {
    border: "1px solid #e74c3c",
    borderRadius: "4px",
    marginBottom: "20px",
    overflow: "hidden",
  },
  teamHeader: {
    backgroundColor: "#fff",
    padding: "10px 15px",
    fontWeight: "bold",
    borderBottom: "1px solid #eee",
  },
  table: { width: "100%", borderCollapse: "collapse" },
  td: { padding: "10px 15px", borderBottom: "1px solid #f0f0f0" },
  btn: {
    padding: "5px 12px",
    color: "#fff",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
  input: {
    padding: "4px 8px",
    border: "1px solid #ccc",
    borderRadius: "4px",
    width: "100px",
  },
};

export default Teams;
