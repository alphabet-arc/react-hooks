import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";

class Header extends Component {
  handleLogout = () => {
    localStorage.removeItem("token");
    this.props.history.push("/login");
  };

  render() {
    return (
      <div style={styles.wrapper}>
        <div style={styles.topBar}>
          <Link to="/addMember" style={styles.topLink}>
            Add Member
          </Link>
          <Link to="/moveMember" style={styles.topLink}>
            Move Member
          </Link>
        </div>
        <div style={styles.header}>
          <span style={styles.title}>Team Tracker</span>
          <div style={styles.icons}>
            <span
              style={styles.icon}
              onClick={() => this.props.history.push("/")}
              title="Home"
            >
              🏠
            </span>
            <span
              style={styles.icon}
              onClick={this.handleLogout}
              title="Logout"
            >
              ➡️
            </span>
          </div>
        </div>
      </div>
    );
  }
}

const styles = {
  wrapper: { width: "100%" },
  topBar: {
    display: "flex",
    justifyContent: "flex-end",
    backgroundColor: "#fff",
    padding: "5px 20px",
    gap: "20px",
  },
  topLink: { textDecoration: "none", color: "#333", fontSize: "14px" },
  header: {
    backgroundColor: "#e74c3c",
    color: "#fff",
    padding: "15px 20px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  title: { fontSize: "22px", fontWeight: "bold" },
  icons: { display: "flex", gap: "10px" },
  icon: { cursor: "pointer", fontSize: "20px" },
};

export default withRouter(Header);
