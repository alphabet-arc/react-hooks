import React, { Component } from "react";
import Header from "../Components/Header";

class MoveMember extends Component {
  state = {
    teams: [],
    data: [],
    empId: "",
    errorStmtEmpId: "",
    fromTeam: "",
    toTeam: "",
  };

  componentDidMount() {
    if (localStorage.getItem("token")) {
      this.handleGetTeam();
      this.handleGetMembers("/api/tracker/members/display");
    } else {
      if (this.props.history) this.props.history.push("/login");
    }
  }

  getLocalStorage = () => {
    return localStorage.getItem("token");
  };

  handleGetTeam = async () => {
    try {
      const response = await fetch("/api/tracker/technologies/get", {
        headers: { Authorization: `Bearer ${this.getLocalStorage()}` },
      });
      const teams = await response.json();
      this.setState({ teams });
    } catch (e) {
      console.log(e);
    }
  };

  handleGetMembers = async (url) => {
    try {
      const response = await fetch(url, {
        headers: { Authorization: `Bearer ${this.getLocalStorage()}` },
      });
      const data = await response.json();
      this.setState({ data });
    } catch (e) {
      console.log(e);
    }
  };

  handleChange = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleClear = () => {
    this.setState({
      empId: "",
      fromTeam: "",
      toTeam: "",
      errorStmtEmpId: "",
    });
  };

  MoveRequest = async () => {
    try {
      const response = await fetch("/api/tracker/members/move", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.getLocalStorage()}`,
        },
        body: JSON.stringify({
          employee_id: Number(this.state.empId),
          technology_name: this.state.toTeam,
        }),
      });
      return response.status;
    } catch (e) {
      console.log(e);
    }
  };

  handleMove = async (e) => {
    const status = await this.MoveRequest();
    if (status === 200) {
      this.handleClear();
      this.handleGetMembers("/api/tracker/members/display");
    }
  };

  render() {
    const { teams, empId, fromTeam, toTeam, errorStmtEmpId } = this.state;

    const isMoveEnabled = empId !== "" && fromTeam !== "" && toTeam !== "";

    return (
      <>
        <Header />
        <form className="MoveMember">
          <h1>Move Team Member</h1>
          <input
            type="text"
            name="empId"
            placeholder="Employee ID"
            value={empId}
            onChange={this.handleChange}
          />
          {errorStmtEmpId && <span>{errorStmtEmpId}</span>}

          <div className="fromTo">
            <label>From</label>
            <select
              name="fromTeam"
              value={fromTeam}
              onChange={this.handleChange}
            >
              <option value="">--Select Team--</option>
              {teams.map((t) => (
                <option key={t._id} value={t.name}>
                  {t.name}
                </option>
              ))}
            </select>

            <label>To</label>
            <select
              name="toTeam"
              value={toTeam}
              onChange={this.handleChange}
            >
              <option value="">--Select Team--</option>
              {teams.map((t) => (
                <option key={t._id} value={t.name}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          <div className="row3">
            <button
              className="add"
              type="button"
              disabled={!isMoveEnabled}
              onClick={this.handleMove}
            >
              Move
            </button>
            <button className="add" type="button" onClick={this.handleClear}>
              Clear
            </button>
          </div>
        </form>
      </>
    );
  }
}

export default MoveMember;
